/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class table {
    public static void main(String[]args){
        try{
            String userTable="create table user(userName Varchar(20),password varchar(10)) ";
            Dboperations.setDataOrDelete(userTable,"user table created successfully");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
