/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author HP
 */
public interface Account {
    public boolean createAccount(String name, String ID, String password);
    public boolean login(String Id, String password);
    public boolean editSettings(String NewPassword, String Id);
    
}
