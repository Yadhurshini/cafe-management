/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.sql.ResultSet;



/**
 *
 * @author HP
 */
public class OrderControl {
    

public class Order {
	Order obj_M_Order = new  Order();
	
	public String orderFood(String customerId, String Bill) {
	
	String orderId = obj_M_Order.orderFood(customerId, Bill);
		return orderId;
	}
	public void addOrderDetails(String orderId, String[] array_itemName, String[] array_itemQuantity) {
		obj_M_Order.addOrderDetails(orderId, array_itemName, array_itemQuantity);
	}
	public ResultSet viewBill(String customerId){
		ResultSet rs = obj_M_Order.viewBill(customerId);
		return rs;
	}
    
}
} 
